﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace StarWarsShips.Models.DBContext
{
    public partial class StarWarsContext : DbContext
    {
        public StarWarsContext()
        {
        }

        public StarWarsContext(DbContextOptions<StarWarsContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Film> Films { get; set; } = null!;
        public virtual DbSet<Pilot> Pilots { get; set; } = null!;
        public virtual DbSet<Starship> Starships { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Data Source=.;Initial Catalog=StarWars;Integrated Security=True");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Film>(entity =>
            {
                entity.HasKey(e => e.FilmsId)
                    .HasName("PK__Films__DC9018F199122EBA");

                entity.Property(e => e.FilmsId).HasColumnName("FilmsID");

                entity.Property(e => e.FkStarship).HasColumnName("FK_Starship");

                entity.Property(e => e.Link)
                    .HasMaxLength(60)
                    .HasColumnName("LINK");

                entity.HasOne(d => d.FkStarshipNavigation)
                    .WithMany(p => p.Films)
                    .HasForeignKey(d => d.FkStarship)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Films__FK_Starsh__5AEE82B9");
            });

            modelBuilder.Entity<Pilot>(entity =>
            {
                entity.HasKey(e => e.PilotsId)
                    .HasName("PK__Pilots__037397126C99B930");

                entity.Property(e => e.PilotsId).HasColumnName("PilotsID");

                entity.Property(e => e.FkStarship).HasColumnName("FK_Starship");

                entity.Property(e => e.Link)
                    .HasMaxLength(60)
                    .HasColumnName("LINK");

                entity.HasOne(d => d.FkStarshipNavigation)
                    .WithMany(p => p.Pilots)
                    .HasForeignKey(d => d.FkStarship)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Pilots__FK_Stars__5812160E");
            });

            modelBuilder.Entity<Starship>(entity =>
            {
                entity.HasKey(e => e.StarshipsId)
                    .HasName("PK__Starship__FE311E13DB26EBCB");

                entity.Property(e => e.StarshipsId).HasColumnName("StarshipsID");

                entity.Property(e => e.CargoCapacity)
                    .HasMaxLength(20)
                    .HasDefaultValueSql("('0')");

                entity.Property(e => e.Consumables)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.CostInCredits)
                    .HasMaxLength(30)
                    .HasColumnName("Cost_in_credits");

                entity.Property(e => e.Created)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Crew).HasMaxLength(10);

                entity.Property(e => e.Edited)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.HyperdriveRating).HasMaxLength(10);

                entity.Property(e => e.Manufacturer).HasMaxLength(120);

                entity.Property(e => e.MaxAtmspeed)
                    .HasMaxLength(10)
                    .HasColumnName("MaxATMSpeed");

                entity.Property(e => e.Mglt)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("MGLT")
                    .HasDefaultValueSql("('0')");

                entity.Property(e => e.Model).HasMaxLength(60);

                entity.Property(e => e.Passengers).HasMaxLength(20);

                entity.Property(e => e.ShipUrl)
                    .HasMaxLength(40)
                    .HasColumnName("ShipURL");

                entity.Property(e => e.StarshipClass)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.StarshipLength).HasMaxLength(10);

                entity.Property(e => e.StarshipName).HasMaxLength(60);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
