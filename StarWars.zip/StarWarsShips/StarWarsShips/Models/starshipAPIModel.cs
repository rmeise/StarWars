﻿using StarWarsShips.Models;

namespace StarWarsShips.Models
{
    public class starshipAPIModel
    {
        public int count { get; set; }
        public string next { get; set; } = string.Empty;
        public string previous { get; set; } = string.Empty;

        public Starship[]? results = new Starship[10];
    }
}
//"count": 36,
//	"next": "https://swapi.dev/api/starships/?page=2",
//	"previous": null,
//	"results": [