﻿namespace StarWarsShips.Models
{
    public class Starship
    {
        public int starshipID { get; set; }
        public string name { get; set; } = string.Empty;
        public string model { get; set; } = string.Empty;
        public string manufacturer { get; set; } = string.Empty;
        public string cost_in_credits { get; set; } = string.Empty;
        public string length { get; set; } = string.Empty;
        public string max_atmosphering_speed { get; set; } = string.Empty;
        public string crew { get; set; } = string.Empty;
        public string passengers { get; set; } = string.Empty;
        public string cargo_capacity { get; set; } = string.Empty;
        public string consumables { get; set; } = string.Empty;
        public string hyperdrive_rating { get; set; } = string.Empty;
        public string MGLT { get; set; } = string.Empty;
        public string starship_class { get; set; } = string.Empty;
        public List<string>? pilots { get; set; }
        public List<string>? films { get; set; }
        public string created { get; set; } = string.Empty;
        public string edited { get; set; } = string.Empty;
        public string url { get; set; } = string.Empty;

    }
}


//StarshipsID INT NOT NULL IDENTITY(1,1),
// StarshipName NVARCHAR(60) NOT NULL,
// Model NVARCHAR(60) NOT NULL,
// Manufacturer NVARCHAR(120) NOT NULL,
// Cost_in_credits NVARCHAR(30) NOT NULL,
// StarshipLength NVARCHAR(10) NOT NULL,
// MaxATMSpeed NVARCHAR(10),
// Crew NVARCHAR(20) NOT NULL,
// Passengers NVARCHAR(10),
// CargoCapacity NVARCHAR(20) DEFAULT '0' NOT NULL,
// Consumables VARCHAR(10),
// HyperdriveRating float,
// MGLT VARCHAR(10) DEFAULT '0' NOT NULL,
// StarshipClass VARCHAR(50),
// FK_Pilots INT,
// FK_Films INT,
// Created VARCHAR(40) NOT NULL,
// Edited VARCHAR(40) NOT NULL,
// ShipURL NVARCHAR(40) NOT NULL,
// PRIMARY KEY(StarshipsID),
// FOREIGN KEY(FK_Pilots) REFERENCES Pilots(PilotsID),
// FOREIGN KEY(FK_Films) REFERENCES Films(FilmsID)