﻿using Microsoft.AspNetCore.Mvc;
using StarWarsShips.DataAccess;
using StarWarsShips.Models;
using StarWarsShips.ViewModel;

namespace StarWarsShips.Controllers
{
    public class ShipController : Controller
    {
        private readonly IDataRepo _dataRepo;
        public ShipController(IDataRepo dataRepo)
        {
            _dataRepo = dataRepo;
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult AddNewShip()
        {
            return View();
        }
        [HttpPost]
        public IActionResult AddNewShip(StarshipViewModel starshipViewModel)
        {
            if(ModelState.IsValid)
            {
                // save ship
                if(_dataRepo.AddStarshipFromView(starshipViewModel))
                    return RedirectToAction("Index","Home");
            }
            ViewBag.Message = "Something went wrong!! Please try again..";
            return View();
        }

        [HttpGet]
        public IActionResult EditShip(int ID)
        {
            return View(_dataRepo.GetStarshipByID(ID));
        }
        [HttpPost]
        public IActionResult EditShip(StarshipViewModel starshipViewModel)
        {
            if (ModelState.IsValid)
            {
                if (_dataRepo.UpdateStarship(starshipViewModel))
                    return RedirectToAction("Index", "Home");
                ViewBag.Message = "Something went wrong!! Please try again..";
                return View();

            }
            return View();
        }

        [HttpPost]
        public IActionResult AddPilotsEntry(string submit)
        {
            Pilots P = new Pilots();
            P.FkStarship = Convert.ToInt32(submit);
            return View(P);
        }
        [HttpPost]
        public IActionResult AddPilot(Pilots pilot)
        {
            if(ModelState.IsValid)
            {
                int x = 0;
            }
           
            return View(pilot);
        }

        [HttpPost]
        public IActionResult AddFilmsEntry(string submit)
        {
            Films F = new Films();
            F.FkStarship = Convert.ToInt32(submit);
            return View(F);
        }

        [HttpPost]
        public IActionResult AddFilm(Films film)
        {
            return View();
        }

        [HttpGet]
        public IActionResult DeleteShip(int ID)
        {
            bool result = _dataRepo.DeleteStarship(ID);

            // CREATE SCRIPT TO ASK IF USER WANT TO PROCEED
            // IF FAIL TO DELETE DISPLAY A PAGE WITH THE ERROR (NOT IMPLEMENTED YET)
            if (result)
                return RedirectToAction("Index", "Home");
            else
                return View();


        }

        [HttpGet]
        public IActionResult StarshipList()
        {

            return View(_dataRepo.GetAllShips());
        }


    }
}
