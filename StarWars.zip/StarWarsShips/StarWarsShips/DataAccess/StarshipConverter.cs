﻿using StarWarsShips;
using StarWarsShips.Models;
using StarWarsShips.Models.DBContext;
using StarWarsShips.ViewModel;

namespace StarWarsShips.DataAccess
{
    public class StarshipConverter
    {
        /// <summary>
        /// Convert StarshipViewModel to Starship
        /// </summary>
        /// <param name="starshipViewModel"></param>
        /// <returns></returns>
        public static Models.Starship StarshipViewToStarship(StarshipViewModel starshipViewModel)
        {
            Models.Starship returnStarship = new Models.Starship();
            returnStarship.pilots = new List<string>();
            returnStarship.films = new List<string>();

            returnStarship.name = starshipViewModel.starshipName;
            returnStarship.model = starshipViewModel.model;
            returnStarship.manufacturer = starshipViewModel.Manufacturer;
            returnStarship.cost_in_credits = starshipViewModel.Cost_in_credits;
            returnStarship.length = starshipViewModel.StarshipLength;
            returnStarship.max_atmosphering_speed = starshipViewModel.MaxATMSpeed;
            returnStarship.crew = starshipViewModel.Crew;
            returnStarship.passengers = starshipViewModel.Passengers;
            returnStarship.cargo_capacity = starshipViewModel.CargoCapacity;
            returnStarship.consumables = starshipViewModel.Consumables;
            returnStarship.hyperdrive_rating = starshipViewModel.HyperdriveRating;
            returnStarship.MGLT = starshipViewModel.MGLT;
            returnStarship.starship_class = starshipViewModel.starship_class;
            returnStarship.created = starshipViewModel.Created;
            returnStarship.edited = starshipViewModel.Edited;
            returnStarship.url = starshipViewModel.ShipURL;

            return returnStarship;
        }

        public static Models.Starship StarshipDBContextToStarship(
            Models.DBContext.Starship ship_DB,
            List<Models.DBContext.Pilot> pilots_DB,
            List<Models.DBContext.Film> films_DB)
        {
            Models.Starship Converted_starship = new Models.Starship();
            Converted_starship.films = new List<string>();
            Converted_starship.pilots = new List<string>();

            Converted_starship.starshipID = ship_DB.StarshipsId;
            Converted_starship.name = ship_DB.StarshipName;
            Converted_starship.model = ship_DB.Model;
            Converted_starship.manufacturer = ship_DB.Manufacturer;
            Converted_starship.cost_in_credits = ship_DB.CostInCredits;
            Converted_starship.length = ship_DB.StarshipLength;
            Converted_starship.max_atmosphering_speed = ship_DB.MaxAtmspeed;
            Converted_starship.crew = ship_DB.Crew;
            Converted_starship.passengers = ship_DB.Passengers;
            Converted_starship.cargo_capacity = ship_DB.CargoCapacity;
            Converted_starship.consumables = ship_DB.Consumables;
            Converted_starship.hyperdrive_rating = ship_DB.HyperdriveRating;
            Converted_starship.MGLT = ship_DB.Mglt;
            Converted_starship.starship_class = ship_DB.StarshipClass;
            Converted_starship.created = ship_DB.Created;
            Converted_starship.edited = ship_DB.Edited;
            Converted_starship.url = ship_DB.ShipUrl;

            if (pilots_DB != null)
            {
                foreach (var item in pilots_DB)
                {
                    string i = item.Link.ToString();
                    Converted_starship.pilots.Add(i);
                }

            }

            if (films_DB != null)
            {
                foreach (var item in films_DB)
                {
                    string i = item.Link.ToString();
                    Converted_starship.films.Add(i);
                }
            }
            return Converted_starship;
        }

        public static ViewModel.StarshipViewModel StarshipToStarshipViewModel(Models.Starship ship)
        {
            StarshipViewModel returnShip = new StarshipViewModel();
            returnShip.strshipID = ship.starshipID;
            returnShip.starshipName = ship.name;
            returnShip.model = ship.model;
            returnShip.Manufacturer = ship.manufacturer;
            returnShip.Cost_in_credits = ship.cost_in_credits;
            returnShip.StarshipLength = ship.length;
            returnShip.MaxATMSpeed = ship.max_atmosphering_speed;
            returnShip.Crew = ship.crew;
            returnShip.Passengers = ship.passengers;
            returnShip.CargoCapacity = ship.cargo_capacity;
            returnShip.Consumables = ship.consumables;
            returnShip.HyperdriveRating = ship.hyperdrive_rating;
            returnShip.MGLT = ship.MGLT;
            returnShip.starship_class = ship.starship_class;
            returnShip.Created = ship.created;
            returnShip.Edited = ship.edited;
            returnShip.ShipURL = ship.url;

            return returnShip;
        }

        public static StarWarsShips.Models.DBContext.Starship StarshipViewModelToStarship_DB(StarshipViewModel ship)
        {
            StarWarsShips.Models.DBContext.Starship returnShip = new StarWarsShips.Models.DBContext.Starship();
            returnShip.StarshipsId = ship.strshipID;
            returnShip.StarshipName = ship.starshipName;
            returnShip.Model = ship.model;
            returnShip.Manufacturer = ship.Manufacturer;
            returnShip.CostInCredits = ship.Cost_in_credits;
            returnShip.StarshipLength = ship.StarshipLength;
            returnShip.MaxAtmspeed = ship.MaxATMSpeed;
            returnShip.Crew = ship.Crew;
            returnShip.Passengers = ship.Passengers;
            returnShip.CargoCapacity = ship.CargoCapacity;
            returnShip.Consumables = ship.Consumables;
            returnShip.HyperdriveRating = ship.HyperdriveRating;
            returnShip.Mglt = ship.MGLT;
            returnShip.StarshipClass = ship.starship_class;
            returnShip.Created = ship.Created;
            returnShip.Edited = ship.Edited;
            returnShip.ShipUrl = ship.ShipURL;

            return returnShip;
        }


    }
}
