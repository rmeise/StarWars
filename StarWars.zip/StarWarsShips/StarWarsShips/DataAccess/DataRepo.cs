﻿using StarWarsShips.DataAccess.API;
using StarWarsShips.SupportClasses;
using StarWarsShips.Models;

using System.Collections.Generic;
using StarWarsShips.DataAccess.DB;
using StarWarsShips.ViewModel;

namespace StarWarsShips.DataAccess
{
    public class DataRepo : IDataRepo
    {
        private readonly IApiAccess _apiAccess;
        private readonly IMockDB _dbAccess_EF;
        private List<Starship> _starshipsList = new List<Starship>();
        public DataRepo(IApiAccess apiAccess, IMockDB dbAccess_EF)
        {
            _apiAccess = apiAccess;
            _dbAccess_EF = dbAccess_EF;
        }
        
        /// <summary>
        /// Get a Starship By ID
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public ViewModel.StarshipViewModel GetStarshipByID(int ID)
        {
            // GET STARSHIP BY ID CONVERT
            return StarshipConverter.StarshipToStarshipViewModel(_dbAccess_EF.GetStarshipByID(ID));
        }

        /// <summary>
        /// Get Rand Starship
        /// </summary>
        /// <returns></returns>
        public Starship GetStarship()
        {
            return _dbAccess_EF.GetStarship();
        }

        public int GetTotalStarshipsNumber()
        {
            return _dbAccess_EF.GetTotalStarshipsNumber();
        }
        /// <summary>
        /// Add Starship
        /// </summary>
        /// <param name="ship"></param>
        public void AddStarship(Starship ship)
        {
            _dbAccess_EF.AddStarship(ship);
        }

        /// <summary>
        /// Populate the DB with Data from the WEBAPI
        /// </summary>
        public void PopulateDB()
        {
            //Fetch Data from API
            _starshipsList = _apiAccess.GetFromApi();
            //Save Data to DB
            foreach (var item in _starshipsList)
            {
                _dbAccess_EF.AddStarship(item);
            }
        }
        public bool DeleteStarship(int ID)
        {
            return _dbAccess_EF.DeleteStarship(ID);            
        }

        public bool AddStarshipFromView(StarshipViewModel starshipViewModel)
        {
            try
            {
                AddStarship(StarshipConverter.StarshipViewToStarship(starshipViewModel));
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool UpdateStarship(StarshipViewModel starship)
        {
            try
            {
                return _dbAccess_EF.UpdateStarship(StarshipConverter.StarshipViewModelToStarship_DB(starship));
            }
            catch (Exception)
            {
                return false;
            }
        }
        public void AddAPilot(Pilots pilot)
        {
            _dbAccess_EF.AddAPilot(pilot);
        }
        public void AddAFilm(Films film)
        {
            _dbAccess_EF.AddAFilm(film);
        }
        public List<Models.Starship> GetAllShips()
        {
            return _dbAccess_EF.GetAllStarships();
        }
    }
}
