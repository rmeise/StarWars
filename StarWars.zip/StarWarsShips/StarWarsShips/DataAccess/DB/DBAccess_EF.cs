﻿using StarWarsShips.Models;
using StarWarsShips.Models.DBContext;
using StarWarsShips.DataAccess;

namespace StarWarsShips.DataAccess.DB
{
    public class DBAccess_EF : IMockDB
    {
        StarWarsContext _context;
        public DBAccess_EF(StarWarsContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Add a Spaceship to the DB using EF
        /// </summary>
        /// <param name="item"></param>
        public void AddStarship(Models.Starship item)
        {
            try
            {
                int ID;
                Models.DBContext.Starship ship = new Models.DBContext.Starship()
                {
                    StarshipName = item.name,
                    Model = item.model,
                    Manufacturer = item.manufacturer,
                    CostInCredits = item.cost_in_credits,
                    StarshipLength = item.length,
                    MaxAtmspeed = item.max_atmosphering_speed,
                    Crew = item.crew,
                    Passengers = item.passengers,
                    CargoCapacity = item.cargo_capacity,
                    Consumables = item.consumables,
                    HyperdriveRating = item.hyperdrive_rating,
                    Mglt = item.MGLT,
                    StarshipClass = item.starship_class,
                    //FkPilots = item.pilots,
                    //FkFilms = item.films,
                    Created = item.created,
                    Edited = item.edited,
                    ShipUrl = item.url
                };

                _context.Starships.Add(ship);
                _context.SaveChanges();
                ID = _context.Starships.Where(O => O.StarshipName == item.name).FirstOrDefault().StarshipsId;

                #region ADD FILMS AND PILOTS
                if (item.films.Count > 0)
                {
                    foreach (var i in item.films)
                    {
                        Models.DBContext.Film film = new Film();
                        film.FkStarship = ID;
                        film.Link = i;
                        _context.Add(film);
                        _context.SaveChanges();
                    }
                }
                if (item.pilots.Count > 0)
                {
                    foreach (var i in item.pilots)
                    {
                        Models.DBContext.Pilot pilot = new Pilot();
                        pilot.FkStarship = ID;
                        pilot.Link = i;
                        _context.Add(pilot);
                        _context.SaveChanges();
                    }
                }
                #endregion ADD FILMS AND PILOTS

            }
            catch (Exception e)
            {
                Console.WriteLine("Error --> MockStockRepositoryEF --> AddStock: " + e.Message);
                //return "ERROR";
            }
        }

        
        public bool DeleteStarship(int ID)
        {
            try
            {
                _context.Starships.Remove(_context.Starships.Where(O => O.StarshipsId == ID).SingleOrDefault());
                _context.Pilots.RemoveRange(_context.Pilots.Where(O => O.FkStarship == ID).ToList());
                _context.Films.RemoveRange(_context.Films.Where(O => O.FkStarship == ID).ToList());
                _context.SaveChanges();
                return true;
            }
            catch (Exception)
            {

                return false;
            }

            
        }

        public int GetTotalStarshipsNumber()
        {
            return _context.Starships.Count();
        }

        /// <summary>
        /// Gets a random Starship
        /// </summary>
        /// <returns></returns>
        public Models.Starship GetStarship()
        {
            // for the ships
            int totalElements = _context.Starships.Count();
            Random random = new Random();
            int ID_to_retrive = 0;
            int shipFound = 0;
            // If number of element is ZERO this method is not called
            // If the random number no longer exists it will find another one..
            while (shipFound != 1)
            {
                ID_to_retrive = random.Next(1, totalElements);
                shipFound = _context.Starships.Where(O => O.StarshipsId == ID_to_retrive).Count();
            }

            Models.DBContext.Starship ship_DB = new Models.DBContext.Starship();
            List<Models.DBContext.Pilot> pilot_DB = new List<Models.DBContext.Pilot>();
            List<Models.DBContext.Film> film_DB = new List<Models.DBContext.Film>();

            // GET A SHIP AND ADD THE LIST OF PILOTS AND FILMS
            ship_DB = _context.Starships.Where(O => O.StarshipsId == ID_to_retrive).FirstOrDefault();
            pilot_DB = _context.Pilots.Where(O => O.FkStarship == ID_to_retrive).ToList();
            film_DB = _context.Films.Where(O => O.FkStarship == ID_to_retrive).ToList();


            return StarshipConverter.StarshipDBContextToStarship(ship_DB, pilot_DB, film_DB);
        }

        public Models.Starship GetStarshipByID(int ID)
        {
            Models.DBContext.Starship ship_DB = new Models.DBContext.Starship();
            List<Models.DBContext.Pilot> pilot_DB = new List<Models.DBContext.Pilot>();
            List<Models.DBContext.Film> film_DB = new List<Models.DBContext.Film>();

            ship_DB = _context.Starships.Where(O => O.StarshipsId == ID).SingleOrDefault();
            pilot_DB = _context.Pilots.Where(O => O.FkStarship == ID).ToList();
            film_DB = _context.Films.Where(O => O.FkStarship == ID).ToList();

            return StarshipConverter.StarshipDBContextToStarship(ship_DB, pilot_DB, film_DB);

        }

        public bool UpdateStarship(StarWarsShips.Models.DBContext.Starship starship)
        {            
            try
            {
                _context.Starships.Update(starship);
                _context.SaveChanges();
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }

        public void AddAPilot(Pilots pilot)
        {
            Pilot P = new Pilot();
            P.FkStarship = pilot.FkStarship;
            P.Link = pilot.pilotURL;

            _context.Pilots.Add(P);
            _context.SaveChanges();
        }
        public void AddAFilm(Films film)
        {
            Film F = new Film();
            F.FkStarship = film.FkStarship;
            F.Link = film.filmURL;

            _context.Films.Add(F);
            _context.SaveChanges();
        }
        public List<Models.Starship> GetAllStarships()
        {
            List<Models.DBContext.Starship> starshipContect = _context.Starships.ToList();

            List<Models.Starship> returnShip = new List<Models.Starship>();
            foreach (var item in starshipContect)
            {
                Models.Starship ship = new Models.Starship();
                List<Models.DBContext.Pilot> pilot_db = _context.Pilots.Where(O => O.FkStarship == item.StarshipsId).ToList();
                List<Models.DBContext.Film> film_db = _context.Films.Where(O => O.FkStarship == item.StarshipsId).ToList();
                ship = StarshipConverter.StarshipDBContextToStarship(item, pilot_db, film_db);
                returnShip.Add(ship);
            }
            return returnShip;
        }
    }
}
