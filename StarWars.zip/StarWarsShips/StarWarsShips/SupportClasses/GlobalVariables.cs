﻿using System.Net;

namespace StarWarsShips.SupportClasses
{
    public class GlobalVariables
    {
        public static HttpClient WebApiClient = new HttpClient();
        public static string Uri = "https://swapi.dev/api/starships/";
        static GlobalVariables()
        {
            WebApiClient.DefaultRequestHeaders.Clear();
            WebApiClient.BaseAddress = new Uri(Uri);
            //WebApiClient.BaseAddress = new Uri("https://swapi.dev/api/starships/0/");0/ --> 35/
            //WebApiClient.BaseAddress = new Uri("https://localhost:7153");        
            WebApiClient.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
            //WebApiClient.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));


        }
    }
}
