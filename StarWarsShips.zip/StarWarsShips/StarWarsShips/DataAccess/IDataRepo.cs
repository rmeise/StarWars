﻿using StarWarsShips.Models;
using StarWarsShips.ViewModel;

namespace StarWarsShips.DataAccess
{
    public interface IDataRepo
    {
        public bool StarshipExist(int ID);
        public void PopulateDB();
        public void AddStarship(Starship ship);
        public bool AddStarshipFromView(StarshipViewModel starshipViewModel);

        public int GetTotalStarshipsNumber();
        public Starship GetStarship();
        public ViewModel.StarshipViewModel GetStarshipByID(int ID);
        public Models.Starship GetStarshipModelByID(int ID);

        public bool DeleteStarship(int ID);

        public bool UpdateStarship(StarshipViewModel starship);

        public void AddAPilot(Pilots pilot);
        public void AddAFilm(Films film);

        public List<Models.Starship> GetAllShips();
    }
}
