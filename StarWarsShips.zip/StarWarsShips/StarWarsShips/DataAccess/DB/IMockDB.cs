﻿using StarWarsShips.Models;

namespace StarWarsShips.DataAccess.DB
{
    public interface IMockDB
    {
        /// <summary>
        /// Save Starship
        /// </summary>
        /// <param name="item"></param>
        public void AddStarship(Starship item);

        public bool StarshipExist(int ID);

        /// <summary>
        /// Delete Starship
        /// </summary>
        /// <param name="item"></param>
        public bool DeleteStarship(int ID);

        public int GetTotalStarshipsNumber();

        /// <summary>
        /// Get a Ship
        /// </summary>
        /// <returns></returns>
        public Starship GetStarship();

        /// <summary>
        /// Update Ship
        /// </summary>
        /// <param name="item"></param>
        public Starship GetStarshipByID(int ID);

        public bool UpdateStarship(StarWarsShips.Models.DBContext.Starship starship);

        public void AddAPilot(Pilots pilot);
        public void AddAFilm(Films film);

        public List<Starship> GetAllStarships();


    }
}
