﻿using StarWarsShips.Models;

namespace StarWarsShips.DataAccess.API
{
    public interface IApiAccess
    {
        public List<Starship> GetFromApi();
    }
}
