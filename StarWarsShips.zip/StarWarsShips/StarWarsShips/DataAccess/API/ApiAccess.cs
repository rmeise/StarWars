﻿using StarWarsShips.SupportClasses;
using StarWarsShips.Models;
using Newtonsoft.Json;


namespace StarWarsShips.DataAccess.API
{
    public class ApiAccess : IApiAccess
    {
        public List<Starship> GetFromApi()
        {
            starshipAPIModel? _starshipAPIModel = new starshipAPIModel();
            List<Starship> _starshipsList = new List<Starship>();

            _starshipAPIModel.next = GlobalVariables.Uri;

            while (_starshipAPIModel.next != null)
            {
                var getTask = GlobalVariables.WebApiClient.GetStringAsync(_starshipAPIModel.next);
                getTask.Wait();
                var result = getTask.Result;
                _starshipAPIModel = JsonConvert.DeserializeObject<starshipAPIModel>(result);

                foreach (var item in _starshipAPIModel.results)
                {
                    _starshipsList.Add(item);
                }
            }
            return _starshipsList;

        }
    }
}
