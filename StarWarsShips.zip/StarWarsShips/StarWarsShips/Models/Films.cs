﻿using System.ComponentModel.DataAnnotations;

namespace StarWarsShips.Models
{
    public class Films
    {
        public int filmID { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Field is required!")]
        [Display(Name = "Starship Name")]
        [MaxLength(60)]
        [MinLength(1)]
        public string filmURL { get; set; } = string.Empty;
        public int FkStarship { get; set; }
    }
}
