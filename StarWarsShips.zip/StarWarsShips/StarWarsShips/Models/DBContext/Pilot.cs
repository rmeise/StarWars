﻿using System;
using System.Collections.Generic;

namespace StarWarsShips.Models.DBContext
{
    public partial class Pilot
    {
        public int PilotsId { get; set; }
        public string? Link { get; set; }
        public int FkStarship { get; set; }

        public virtual Starship FkStarshipNavigation { get; set; } = null!;
    }
}
