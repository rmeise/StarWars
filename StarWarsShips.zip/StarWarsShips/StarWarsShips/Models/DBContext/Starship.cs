﻿using System;
using System.Collections.Generic;

namespace StarWarsShips.Models.DBContext
{
    public partial class Starship
    {
        public Starship()
        {
            Films = new HashSet<Film>();
            Pilots = new HashSet<Pilot>();
        }

        public int StarshipsId { get; set; }
        public string StarshipName { get; set; } = null!;
        public string Model { get; set; } = null!;
        public string Manufacturer { get; set; } = null!;
        public string CostInCredits { get; set; } = null!;
        public string StarshipLength { get; set; } = null!;
        public string? MaxAtmspeed { get; set; }
        public string Crew { get; set; } = null!;
        public string? Passengers { get; set; }
        public string CargoCapacity { get; set; } = null!;
        public string? Consumables { get; set; }
        public string? HyperdriveRating { get; set; }
        public string Mglt { get; set; } = null!;
        public string? StarshipClass { get; set; }
        public string Created { get; set; } = null!;
        public string Edited { get; set; } = null!;
        public string ShipUrl { get; set; } = null!;

        public virtual ICollection<Film> Films { get; set; }
        public virtual ICollection<Pilot> Pilots { get; set; }
    }
}
