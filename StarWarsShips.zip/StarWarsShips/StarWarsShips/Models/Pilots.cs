﻿using System.ComponentModel.DataAnnotations;

namespace StarWarsShips.Models
{
    public class Pilots
    {
        public int pilotID { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Field is required!")]
        [Display(Name = "Starship Name")]
        [MaxLength(60)]
        [MinLength(1)]
        public string pilotURL { get; set; } = string.Empty;

        public int FkStarship { get; set; }
    }
}
