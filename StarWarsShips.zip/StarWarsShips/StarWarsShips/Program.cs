using Microsoft.EntityFrameworkCore;
using StarWarsShips.DataAccess;
using StarWarsShips.DataAccess.API;
using StarWarsShips.DataAccess.DB;
using StarWarsShips.Models.DBContext;
using StarWarsShips.SupportClasses;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddScoped<IDataRepo, DataRepo>();
builder.Services.AddScoped<IApiAccess, ApiAccess>();
builder.Services.AddScoped<IMockDB, DBAccess_EF>();

builder.Services.AddDbContext<StarWarsContext>(options =>
{
    options.UseSqlServer(builder.Configuration.GetConnectionString("ConnectionString"));
});

var app = builder.Build();
 
// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{

}
if (!app.Environment.IsDevelopment())
{
    //DeveloperExceptionPageOptions developerExceptionPageOptions = new DeveloperExceptionPageOptions()
    //{
    //    SourceCodeLineCount = 10
    //};
    app.UseExceptionHandler("/Error/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
    //app.UseDeveloperExceptionPage();
}
else if (!app.Environment.IsStaging() || !app.Environment.IsProduction() || !app.Environment.IsEnvironment("UAT"))
{
    app.UseExceptionHandler("/Error");
    app.UseStatusCodePagesWithReExecute("/Error/{0}");
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
