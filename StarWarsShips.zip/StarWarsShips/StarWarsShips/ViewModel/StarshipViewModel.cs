﻿using System.ComponentModel.DataAnnotations;

namespace StarWarsShips.ViewModel
{
    public class StarshipViewModel
    {

        public int strshipID { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Field is required!")]
        [Display(Name = "Starship Name")]
        [MaxLength(60)]
        [MinLength(1)]
        public string starshipName { get; set; } = string.Empty;

        [Required(AllowEmptyStrings = false, ErrorMessage = "Field is required!")]
        [Display(Name = "Starship Model")]
        [MaxLength(60)]
        [MinLength(1)]
        public string model { get; set; } = string.Empty;
        
        [Required(AllowEmptyStrings = false, ErrorMessage = "Field is required!")]
        [Display(Name = "Starship Manufacturer")]
        [MaxLength(120)]
        [MinLength(1)]
        public string Manufacturer { get; set; } = string.Empty;

        [Required(AllowEmptyStrings = false, ErrorMessage = "Field is required!")]
        [Display(Name = "Starship Cost")]
        [MaxLength(30)]
        [MinLength(1)]
        [RegularExpression(@"^\d+(\.\d{1,2})?$", ErrorMessage = "Must be numeric")]
        public string Cost_in_credits { get; set; } = string.Empty;

        [Required(AllowEmptyStrings = false, ErrorMessage = "Field is required!")]
        [Display(Name = "Starship Length")]
        [MaxLength(10)]
        [MinLength(1)]
        [RegularExpression(@"^\d+(\.\d{1,2})?$", ErrorMessage = "Must be numeric")]
        public string StarshipLength { get; set; } = string.Empty;

        [Required(AllowEmptyStrings = false, ErrorMessage = "Field is required!")]
        [Display(Name = "Starship ATM Speed")]
        [MaxLength(10)]
        [MinLength(1)]
        [RegularExpression(@"^\d+(\.\d{1,2})?$", ErrorMessage = "Must be numeric")]
        public string MaxATMSpeed { get; set; } = string.Empty;


        [Required(AllowEmptyStrings = false, ErrorMessage = "Field is required!")]
        [Display(Name = "Crew")]
        [MaxLength(10)]
        [MinLength(1)]
        [RegularExpression(@"^\d+(\.\d{1,2})?$", ErrorMessage = "Must be numeric")] 
        public string Crew { get; set; } = string.Empty;

        [Required(AllowEmptyStrings = false, ErrorMessage = "Field is required!")]
        [Display(Name = "Total Passengers")]
        [MaxLength(20)]
        [MinLength(1)]
        [RegularExpression(@"^\d+(\.\d{1,2})?$", ErrorMessage = "Must be numeric")]
        public string Passengers { get; set; } = string.Empty;

        [Required(AllowEmptyStrings = false, ErrorMessage = "Field is required!")]
        [Display(Name = "Cargo in KGs")]
        [MaxLength(20)]
        [MinLength(1)]
        [RegularExpression(@"^\d+(\.\d{1,2})?$", ErrorMessage = "Must be numeric")]
        public string CargoCapacity { get; set; } = string.Empty;

        [Required(AllowEmptyStrings = false, ErrorMessage = "Field is required!")]
        [Display(Name = "Consumables")]
        [MaxLength(20)]
        [MinLength(1)]
        public string Consumables { get; set; } = string.Empty;

        [Display(Name = "Hyperdrive")]
        [MaxLength(10)]
        [MinLength(1)]
        [RegularExpression(@"^\d+(\.\d{1,2})?$", ErrorMessage = "Must be numeric")]
        public string HyperdriveRating { get; set; } = string.Empty;

        [Required(AllowEmptyStrings = false, ErrorMessage = "Field is required!")]
        [Display(Name = "MGLT")]
        [MaxLength(10)]
        [MinLength(1)]
        [RegularExpression(@"^\d+(\.\d{1,2})?$", ErrorMessage = "Must be numeric")]
        public string MGLT { get; set; } = string.Empty;

        [Required(AllowEmptyStrings = false, ErrorMessage = "Field is required!")]
        [Display(Name = "Ship Class")]
        [MaxLength(50)]
        [MinLength(1)]
        public string starship_class { get; set; } = string.Empty;
        public List<string>? listOfFilms { get; set; }
        public List<string>? listOfPilots { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Field is required!")]
        [Display(Name = "Created")]
        [MaxLength(40)]
        [MinLength(1)]
        public string Created { get; set; } = string.Empty;

        [Required(AllowEmptyStrings = false, ErrorMessage = "Field is required!")]
        [Display(Name = "Edited")]
        [MaxLength(40)]
        [MinLength(1)]
        public string Edited { get; set; } = string.Empty;

        [Required(AllowEmptyStrings = false, ErrorMessage = "Field is required!")]
        [Display(Name = "ShipURL")]
        [MaxLength(40)]
        [MinLength(1)]
        public string ShipURL { get; set; } = string.Empty;

    }
}


//StarshipsID INT NOT NULL IDENTITY(1,1),
// StarshipName NVARCHAR(60) NOT NULL,
// Model NVARCHAR(60) NOT NULL,
// Manufacturer NVARCHAR(120) NOT NULL,
// Cost_in_credits NVARCHAR(30) NOT NULL,
// StarshipLength NVARCHAR(10) NOT NULL,
// MaxATMSpeed NVARCHAR(10),
// Crew NVARCHAR(20) NOT NULL,
// Passengers NVARCHAR(10),
// CargoCapacity NVARCHAR(20) DEFAULT '0' NOT NULL,
// Consumables VARCHAR(10),
// HyperdriveRating float,
// MGLT VARCHAR(10) DEFAULT '0' NOT NULL,
// StarshipClass VARCHAR(50),
// FK_Pilots INT,
// FK_Films INT,
// Created VARCHAR(40) NOT NULL,
// Edited VARCHAR(40) NOT NULL,
// ShipURL NVARCHAR(40) NOT NULL,
// PRIMARY KEY(StarshipsID),
// FOREIGN KEY(FK_Pilots) REFERENCES Pilots(PilotsID),
// FOREIGN KEY(FK_Films) REFERENCES Films(FilmsID)