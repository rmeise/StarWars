﻿using Microsoft.AspNetCore.Mvc;
using StarWarsShips.DataAccess.API;
using StarWarsShips.Models;
using System.Diagnostics;
using StarWarsShips.DataAccess;
using StarWarsShips.ViewModel;

namespace StarWarsShips.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IDataRepo _dataRepo;

        public HomeController(ILogger<HomeController> logger, IDataRepo dataRepo)
        {
            _logger = logger;
            _dataRepo = dataRepo;
        }

        public IActionResult Index()
        {
            // IS THE DB POPULATED?
            // --> IF YES GET A RAND SHIP AND DISPLAY
            // IF NOT
            // REDIRECT TO GETSHIPS 
            // --> GIVE THE USER THE OPTION TO ADD A NEW ONE OR
            // --> REQUEST THE LIST OF SHIPS TO THE API.

            //Check if DB has one or more and return a random spaceship for display!
            if(_dataRepo.GetTotalStarshipsNumber() >= 1)
            {
                Starship starship = _dataRepo.GetStarship();
                return View(starship);
            }
            else
            {
                return RedirectToAction("GetShips", "Home");
            }
        }

        public IActionResult GetShips()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddNewShip()
        {
            return RedirectToAction("AddNewShip", "Ship");
        }

        [HttpPost]
        public IActionResult GetShips(string submit)
        {
            if (submit == "API")
            {
                // Access the WEB API and save all the found records into the DB.
                // Redirect to the main page.
                _dataRepo.PopulateDB();
                return RedirectToAction("Index","Home");
            }
            else
            {
                return RedirectToAction("AddNewShip", "Ship");
            }

        }

        [HttpGet]
        public IActionResult About()
        {
            return View();
        }



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}