USE [StarWars]
GO

CREATE TABLE Starships(
 StarshipsID INT NOT NULL IDENTITY(1,1),
 StarshipName NVARCHAR(60) NOT NULL,
 Model NVARCHAR(60) NOT NULL,
 Manufacturer NVARCHAR(120) NOT NULL,
 Cost_in_credits NVARCHAR(30) NOT NULL,
 StarshipLength NVARCHAR(10) NOT NULL,
 MaxATMSpeed NVARCHAR(10),
 Crew NVARCHAR(10) NOT NULL,
 Passengers NVARCHAR(20),
 CargoCapacity NVARCHAR(20) DEFAULT '0' NOT NULL,
 Consumables VARCHAR(10),
 HyperdriveRating NVARCHAR(10),
 MGLT VARCHAR(10) DEFAULT '0' NOT NULL,
 StarshipClass VARCHAR(50),
 Created VARCHAR(40) NOT NULL,
 Edited VARCHAR(40) NOT NULL,
 ShipURL NVARCHAR(40) NOT NULL,
 PRIMARY KEY(StarshipsID),
 )

CREATE TABLE Pilots(
PilotsID INT NOT NULL IDENTITY(1,1),
LINK NVARCHAR(60),
FK_Starship INT NOT NULL,
PRIMARY KEY(PilotsID),
FOREIGN KEY(FK_Starship) REFERENCES Starships(StarshipsID),
);

CREATE TABLE Films(
FilmsID INT NOT NULL IDENTITY(1,1),
LINK NVARCHAR(60),
FK_Starship INT NOT NULL,
PRIMARY KEY(FilmsID),
 FOREIGN KEY(FK_Starship) REFERENCES Starships(StarshipsID),
);



-- name string -- The name of this starship. The common name, such as "Death Star".
--model string -- The model or official name of this starship. Such as "T-65 X-wing" or "DS-1 Orbital Battle Station".
--starship_class string -- The class of this starship, such as "Starfighter" or "Deep Space Mobile Battlestation"
--manufacturer string -- The manufacturer of this starship. Comma separated if more than one.
--cost_in_credits string -- The cost of this starship new, in galactic credits.
--length string -- The length of this starship in meters.
--crew string -- The number of personnel needed to run or pilot this starship.
--passengers string -- The number of non-essential people this starship can transport.
-- *** N/A != NULL max_atmosphering_speed string -- The maximum speed of this starship in the atmosphere. "N/A" if this starship is incapable of atmospheric flight.
--hyperdrive_rating string -- The class of this starships hyperdrive.
--MGLT string -- The Maximum number of Megalights this starship can travel in a standard hour. A "Megalight" is a standard unit of distance and has never been defined before within the Star Wars universe. This figure is only really useful for measuring the difference in speed of starships. We can assume it is similar to AU, the distance between our Sun (Sol) and Earth.
--cargo_capacity string -- The maximum number of kilograms that this starship can transport.
--consumables *string
--The maximum length of time that this starship can provide consumables for its entire crew without having to resupply.
--films array -- An array of Film URL Resources that this starship has appeared in.
--pilots array -- An array of People URL Resources that this starship has been piloted by.
--url string -- the hypermedia URL of this resource.
--created string -- the ISO 8601 date format of the time that this resource was created.
--edited string -- the ISO 8601 date format of the time that this resource was edited.


 --CREATE TABLE Starships(
 --StarshipsID INT NOT NULL IDENTITY(1,1),
 --StarshipName NVARCHAR(60) NOT NULL,
 --Model NVARCHAR(60) NOT NULL,
 --Manufacturer NVARCHAR(120) NOT NULL,
 --Cost_in_credits VARCHAR(30) NOT NULL,
 --StarshipLength INT NOT NULL,
 --MaxATMSpeed INT NOT NULL,
 --Crew NVARCHAR(20) NOT NULL,
 --Passengers INT,
 --CargoCapacity INT,
 --Consumables VARCHAR(10),
 --HyperdriveRating float,
 --MGLT INT,
 --StarshipClass VARCHAR(50),
 --FK_Pilots INT,
 --FK_Films INT,
 --Created VARCHAR(40) NOT NULL,
 --Edited VARCHAR(40) NOT NULL,
 --ShipURL NVARCHAR(40) NOT NULL,
 --PRIMARY KEY(StarshipsID),
 --FOREIGN KEY(FK_Pilots) REFERENCES Pilots(PilotsID),
 --FOREIGN KEY(FK_Films) REFERENCES Films(FilmsID)
 --)

